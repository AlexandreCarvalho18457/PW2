<!DOCTYPE html>
<html>
<head>
	<title>Aula 9 e 10 Exercicio 3</title>
</head>
<body>
	<?php
		for ($i=1; $i <101 ; $i++) { 
			$t = $i * $i;
			echo $i . " * " . $i . " =  " . $t . "<br>";
		}

	?>
</body>
</html>